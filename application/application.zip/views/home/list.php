 <?php
// load slider
 include('slider.php');
 // Load kategori/banner
 // include('kategori.php');
 // Load data produk
 include('produk.php');
 ?>