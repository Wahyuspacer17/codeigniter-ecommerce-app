<!-- Features Section Begin -->
<section class="features-section spad">
<!-- Features Box -->
<div class="features-box">
<div class="container">
<div class="row">
<div class="col-sm-12 col-md-12 col-lg-12" >
<div class="row">
<div class="col-sm-12 col-md-12 col-lg-12">
    <?php foreach($kategori as $kategori) { ?>
    <div class="block1 hov-img-zoom pos-relative m-b-30 col-md-4">
        <img src="<?php echo base_url() ?>assets/template/images/f-box-2.jpg" alt="">
        <div class="box-text">
            <span class="trend-year">2019 Trend</span>
            <h2>Footwear</h2>
            <span class="trend-alert">Bold & Black</span>
        </div>
    </div>
    <?php } ?>
</div>
</div>
</div>

</div>
</div>
</div>
</section>
<!-- Features Section End -->