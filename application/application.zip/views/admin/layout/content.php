<?php
// memanggil data isi content dari controller variabel isi
if ( $isi )
{
	$this->load->view($isi);
}