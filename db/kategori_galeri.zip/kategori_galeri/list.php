<table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Gambar</th>
                  <th>Judul</th>
                  <th>Kategori-Posisi</th>
                  <th>Website</th>
                  <th>Author</th>
                  <th>Tanggal</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                  <td>1</td>
                  <td>gambar</td>
                  <td>Balairung</td>
                  <td>Wedding-Galeri</td>
                  <td>www.wahyuspacer17@blogspot.com</td>
                  <td>Wahyu Ramadhan</td>
                  <td>20-12-2090</td>
                  <td>
                    <div class="btn-group">
                      <a href="#" class="btn btn-warning btn-sm">
                        <i class="fa fa-edit"></i>
                      </a>
                      <a href="#" class="btn btn-danger btn-sm">
                        <i class="fa fa-trash"></i></a>
                        <a href="#" class="btn btn-success btn-sm">
                        <i class="fa fa-eye"></i></a>
                   </td>
                </tr>
              </tbody>
            </table>